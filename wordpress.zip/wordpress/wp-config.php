<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе установки.
 * Необязательно использовать веб-интерфейс, можно скопировать файл в "wp-config.php"
 * и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки базы данных
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://ru.wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Параметры базы данных: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define( 'DB_NAME', 'wordpress' );

/** Имя пользователя базы данных */
define( 'DB_USER', 'root' );

/** Пароль к базе данных */
define( 'DB_PASSWORD', '' );

/** Имя сервера базы данных */
define( 'DB_HOST', 'localhost' );

/** Кодировка базы данных для создания таблиц. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Схема сопоставления. Не меняйте, если не уверены. */
define( 'DB_COLLATE', '' );

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу. Можно сгенерировать их с помощью
 * {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}.
 *
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными.
 * Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '%nyB>V,dT@Y1*v$;K{H&c8iM0MK_c6W>2Ee*8iP!.UVH5-bUlQ+,]|$<2&M]E6+|' );
define( 'SECURE_AUTH_KEY',  'IqZRn<B*d5Ou[j`a%{]?KR;)*o23z?nd5(N0<G f<OY|O!$gC_toHGz4D]29,ZmG' );
define( 'LOGGED_IN_KEY',    'kQ:66g1^XIiQVgG>fm5U-n%tP{gE_iVa`HJh&:s|u5.p[)Nj`J:H4&2[Bkf&dI4E' );
define( 'NONCE_KEY',        '!Z bGu{L mrM?|oH(`o2L6nXD.YJ_Uxd9m.Uk;VD9:@aVt$$Xh%*NuVfzf|GoV2]' );
define( 'AUTH_SALT',        'l-G}7c0q0B-6I)kJ?dpI$0iH#[_,tFrER`}4.U/E^34e1Sdq`kDdp=1BmPV~(5a,' );
define( 'SECURE_AUTH_SALT', '%kxPJc<!<&84u7n5B2u^^ux>s$&VlLF^odx3ZyO`ZU&[s#jCiBJ4.e:69bK-4*rQ' );
define( 'LOGGED_IN_SALT',   '/q_&Sv$PB%b)lI<+:sF0|$/|Sjq IpIPnoY>NVqMy@_D|*~FNL%%c&eh3!F(S.F=' );
define( 'NONCE_SALT',       'G)T7jojB3OIm|e||/3!w.R-$w.w2n!U8*|P0J35yW{]6@_n~*U&g{og|KQ1EQ_Fy' );

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в документации.
 *
 * @link https://ru.wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Произвольные значения добавляйте между этой строкой и надписью "дальше не редактируем". */



/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Инициализирует переменные WordPress и подключает файлы. */
require_once ABSPATH . 'wp-settings.php';
